tripModule.service('tripServiceHelper',function() {
	console.log('Trip ServiceHelper created!');
}

tripModule.service('tripServicesHelper',function($scope, tripService){
    console.log('Trip Service created!');

});

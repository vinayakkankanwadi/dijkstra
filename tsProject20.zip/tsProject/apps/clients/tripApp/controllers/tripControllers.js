tripModule.controller('tripController',function($scope, tripService){
	console.log('Trip Controller created!');

	//$scope.deals = tripService.list();
	$scope.departures = tripService.getCityList();
	$scope.arrivals = tripService.getCityList();
	//$scope.paths =null;
	
	$scope.totalCost =0;
	$scope.totalTime =0;
	

	 $scope.calcCost = function(cost,discount){
		var total = 0;
		total = cost - cost*discount/100;		
		$scope.totalCost = $scope.totalCost + total;
		console.log(total)
		return total;
	}

	 $scope.calcTime = function(duration){
		var formatTime = duration.h+"h"+duration.m;
		$scope.totalTime = $scope.totalTime + duration.h * 60 + duration.m;
		console.log(formatTime)
		return formatTime;
	}  	
	
    $scope.search = function (source,destination) {
		$scope.searchResult = tripService.search(source,destination); 
		console.log("Controller Search",$scope.searchResult)
		$scope.paths = [];
		
		/*console.log($scope.searchResult[destination])
		var dest = destination;
		$scope.paths.unshift(dest);
		$scope.total = 0;
    	for (pp in $scope.searchResult)
		{
			pt = $scope.searchResult[dest];
			$scope.paths.unshift(pt);
			console.log(pt);
			console.log(source,destination,pt);
			//$scope.total = $scope.total+pt.cost-pt.cost*pt.discount/100
			if( pt == source )
				break;
			dest = pt;
		}*/
		console.log($scope.paths);
		//$scope.update(id);
    }

});
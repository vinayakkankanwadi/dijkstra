tripModule.controller('tripController',function($scope, tripService){
	console.log('Trip Controller created!');

	$scope.deals = tripService.list();
	$scope.departures = tripService.departure();
	$scope.arrivals = tripService.arrival();
	$scope.paths =null;
	
	
    $scope.search = function (source,destination) {
		$scope.searchResult = tripService.search(source,destination); 
		console.log("Controller Search",$scope.searchResult)
		console.log($scope.searchResult[destination])
		var dest = destination;
		$scope.paths = [];
		$scope.paths.unshift(dest);
		$scope.total = 0;
    	for (pp in $scope.searchResult)
		{
			pt = $scope.searchResult[dest];
			$scope.paths.unshift(pt);
			console.log(pt);
			console.log(source,destination,pt);
			//$scope.total = $scope.total+pt.cost-pt.cost*pt.discount/100
			if( pt == source )
				break;
			dest = pt;
		}
		console.log($scope.paths);
		//$scope.update(id);
    }

});